#include <stdio.h>

int main ()
{
	printf ("You have successfully gotten a program to run\n");
	return 0;
}
