#!/bin/sh
#scp blai4021@wormulon.cs.uidaho.edu:CS_210-2/hw06/hw06.tar ./
scp hw06.tar blai4021@wormulon.cs.uidaho.edu:CS_210-2/hw06/
