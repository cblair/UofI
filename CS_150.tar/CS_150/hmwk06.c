#include <stdio.h>

using namespace std;

int main()
{
  int a = 6;
  int b = 9;
  int c = 11;
  a <<= b;

  printf("a = %d\n", a);
}
