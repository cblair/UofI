int arr_sum()
{
  int sum = 0;
  int x;
  for(x = 0; x < SIZE; x++)
    {
      sum += arr[x];
    }

  return(sum);
}
