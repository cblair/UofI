#include <stdio.h>

#define NUMBER 123
#define LETTER '1'

using namespace std;

int main()
{
  printf("$%d.%c", NUMBER, LETTER);
}
