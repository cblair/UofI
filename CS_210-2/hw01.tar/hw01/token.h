struct token {
  int category;
  char *text;
  int   linenumber;
} ;
