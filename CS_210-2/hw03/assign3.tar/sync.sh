#!/bin/sh
#scp blai4021@wormulon.cs.uidaho.edu:CS_210-2/hw03/assign3.tar assign3.tar
scp assign3.tar blai4021@wormulon.cs.uidaho.edu:CS_210-2/hw03/assign3.tar 
