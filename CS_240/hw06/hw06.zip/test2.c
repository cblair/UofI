/* timer.c - simple example of timing a piece of code */

/* c89 timer.c -o timer */

#include <stdio.h>
#include <sys/types.h>
#include <time.h>

main()
{ int i;
  timeval t1,t2;

  (void) time(&t1);
  
  for (i=1;i<=300;++i) printf("%d %d %d\n",i, i*i, i*i*i);
   
   
  (void) time(&t2);
   
  printf("\nTime to do 300 squares and cubes= %f seconds\n", t2 - t1);
}
